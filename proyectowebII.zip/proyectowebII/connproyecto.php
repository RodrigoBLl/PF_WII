<?php
$servername = "localhost";
$username = "id18474503_rodrigollanas";
$password = "7XAm9U{ALuttCdA8";
$dbname = "id18474503_mapa_curricular";
?>